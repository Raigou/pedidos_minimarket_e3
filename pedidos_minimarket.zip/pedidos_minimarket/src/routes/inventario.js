const { render } = require("ejs");
const express = require("express");
const { createPool } = require("mysql");
const router = express.Router();
const conn = require("../database");

/* MOSTRAR TABLA Inventario */
router.get("/", (req, res) => {
  conn.query(
    "SELECT * FROM `producto` ;",
    (err, result) => {
      if (!err) {
        res.render("home.ejs", {
          producto: result,
        });
      } else {
        console.log(err);
      }
    }
  );
});
router.get("/web", (req, res) => {

  conn.query(
    "SELECT * FROM `cliente`",
    (err, result) => {
      if (!err) {
        res.render("web.ejs", {
          producto: result,
        });
      } else {
        console.log(err);
      }
    }
  );
});


router.post('/add',async (req,res)=>{
  const {rut, telefono, contrasena,email,direccion,nombre} = req.body;
  const nuevoRecibido={
    rut,
     telefono, 
     contrasena,
     email,
     direccion,
     nombre
  };
  await conn.query('INSERT INTO cliente set ?',[nuevoRecibido]);

})

router.get('/acceso',(req,res) =>{
  res.render('acceso.ejs');

})
router.post('/acceso',(req,res)=>{
  
  console.log(req.body)
  res.send('recived');
})



router.get("/inventario", (req, res) => {
  conn.query(
    "SELECT inventario.id_inventario,producto.nombre_producto,cantidad FROM inventario INNER JOIN producto ON inventario.id_inventario = producto.id_inventario;",
    (err, result) => {
      if (!err) {
        res.render("inventario.ejs", {
          inventario: result,
        });
      } else {
        console.log(err);
      }
    }
  );
});

router.post("/edit/:id", function (req, res) {
  const { id } = req.params;
  const newA = req.body.cantidad;
  conn.query(
    "UPDATE inventario set cantidad = ? + cantidad WHERE id_inventario=?",[newA[0],id],
    function (err, rs) {
      res.redirect("/");
    }
  );
});
router.get("/inventario", (req, res) => {

  conn.query(
    "SELECT * FROM `producto`",
    (err, result) => {
      if (!err) {
        res.render("inventario.ejs", {
          producto: result,
        });
      } else {
        console.log(err);
      }
    }
  );
});




router.get("/home", (req, res) => {
  conn.query(
    "SELECT * FROM `producto` ;",
    (err, result) => {
      if (!err) {
        res.render("home.ejs", {
          producto: result,
        });
      } else {
        console.log(err);
      }
    }
  );
});

router.get("/frutas", (req, res) => {

  conn.query(
    "SELECT * FROM `producto` WHERE tipo= 'Fruta';",
    (err, result) => {
      if (!err) {
        res.render("frutas.ejs", {
          producto: result,
        });
      } else {
        console.log(err);
      }
    }
  );
});

router.get("/snacks", (req, res) => {

  conn.query(
    "SELECT * FROM `producto` WHERE tipo= 'Snacks';",
    (err, result) => {
      if (!err) {
        res.render("Snacks.ejs", {
          producto: result,
        });
      } else {
        console.log(err);
      }
    }
  );
});


module.exports = router;
